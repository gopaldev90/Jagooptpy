it can be used to sync files from remotely device 
setup:
get your firebase ServiceAccountKeyservice.json file and put it backend folder 
create firebase db and place url appropriately files.
compile it and send it to targeted devices.
# Jagooptpy
# Jagooptpy
