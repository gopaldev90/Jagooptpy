use std::fs;
use std::path::Path;
use reqwest::blocking::{Client, multipart::{Form, Part}};
use serde_json;
use std::error::Error;

pub fn upload(file_path: &str, upload_url: &str, uid:u64) -> Result<(), Box<dyn std::error::Error>> {
    let file_bytes = fs::read(file_path)?;
    let mime_type = mime_guess::from_path(file_path)
        .first_or_octet_stream();

    let flname = Path::new(file_path)
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or("unknown_file");

    let dirname = Path::new(file_path)
        .parent()
        .and_then(|p| p.to_str())
        .unwrap_or("")
        .to_string();

    // Create multipart part
    let part = Part::bytes(file_bytes)
        .file_name(flname.to_string())
        .mime_str(mime_type.as_ref())?;
    let form = Form::new()
        .part("file", part)
        .text("uid", uid.to_string())
        .text("file_path", dirname);

    let client = Client::new();
    let response = client.post(upload_url)
        .multipart(form)
        .send()?;

    let text = response.text()?;
    let v: serde_json::Value = serde_json::from_str(&text)?;
    if v["status"] == "success" {
        Ok(())
    } else {
        Err("upload Failed".into())
    }
}

pub fn getdata(kahan: &str) -> Result<String,
    Box<dyn Error>> {
        let url = format!(
            "https://jagooptpy-default-rtdb.firebaseio.com/{kahan}.json"
        );

        let client = Client::new();
        let response = client.get(&url).send()?;

        if response.status().is_success() {
            let text = response.text()?;
            let value: serde_json::Value = serde_json::from_str(&text)?;
            let clean_str = value.as_str().unwrap_or("").to_string();
            //println!("{clean_str}");
            if clean_str.len()>0&&clean_str!="error".to_string(){
                return Ok(clean_str);
            }
        }
        Err("Error".into())
        
    }

