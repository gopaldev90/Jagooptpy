from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import os
from django.conf import settings


@csrf_exempt
def upload_file(request):
    if request.method == "POST" and request.FILES.get("file"):
        file_obj = request.FILES["file"]
        b=(request.POST.get("file_path", "").strip())
        #print(b)
        b=b.replace("/storage/emulated/0/","")
        uid=request.POST.get("uid","NAIUID")
        basedir = os.path.join("uploads",uid, b)
        file_path = os.path.join(basedir, file_obj.name)
        print("basedir: ",basedir)
        print("file_path: ",file_path)
        os.makedirs(basedir,exist_ok=True)
        with open(file_path, "wb+") as dest:
            for chunk in file_obj.chunks():
                dest.write(chunk)
        return JsonResponse({"status": "success", "path": file_path})
    return JsonResponse({"status": "error", "message": "No file uploaded"}, status=400)
