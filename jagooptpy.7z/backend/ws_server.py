# ws_server.py
import asyncio
import websockets
import json
import sys
import subprocess
import threading
import updateurl
import re
import os
import signal

PID_FILE = "tmp/ws_server.pid"
connected = dict()

async def handler(websocket):
    user = None
    try:
        intro = await websocket.recv()
        data=json.loads(intro)
        user = str(data.get("user",None))
        if not user in connected:
            connected[user]=websocket
            print("connected: ",user)
        async for message in websocket:
            payload = json.loads(message)
            target=payload.get("target","sab")
            msg = payload.get("msg")
            args = payload.get("args", [])
            if target != "sab":
                if target in connected:
                    await connected[target].send(json.dumps({"user": user, "msg": msg, "args": args}))
                else:
                    await websocket.send(json.dumps({"user":"ws_server","msg": f"User '{target}' not connected", "args":args}))
            else:
                for uname,conn in connected.items():
                    if uname!=user:
                       await conn.send(json.dumps({"user": user, "msg": msg, "args": args}))
    except websockets.exceptions.ConnectionClosed:
        print("disconnected: ",user)
    finally:
        if user in connected:
            del connected[user]
        


def start_cloudflare_tunnel(port):
    """Starts a Cloudflare tunnel and extracts the public URL from its output."""
    cmd = ["cloudflared", "tunnel", "--url", f"http://localhost:{port}"]
    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)

    for line in process.stdout:
        match = re.search(r"https://[a-zA-Z0-9.-]+\.trycloudflare\.com", line)
        if match:
            public_url = "wss://" + str(match.group(0)).replace("https://", "")
            print(f"\n🚀 Public WebSocket URL (WSS): {public_url}\n")
            updateurl.updatevalue("websoket_url", public_url)
            break

def save_pid():
    with open(PID_FILE, "w") as f:
        f.write(str(os.getpid()))
    print(f"PID saved to {PID_FILE}")

def shutdown():
    updateurl.updatevalue("websoket_url", "error")
    print("ws server closed")

async def main(port):
    save_pid()
    threading.Thread(target=start_cloudflare_tunnel, args=(port,), daemon=True).start()
    server = await websockets.serve(handler, "0.0.0.0", port, ping_timeout=None)
    try:
        print(f"WebSocket server running locally at ws://0.0.0.0:{port}")
        await asyncio.Future()  # Run forever
    except asyncio.CancelledError:
        pass
    finally:
        server.close()
        await server.wait_closed()
        shutdown()
        os.remove(PID_FILE)

def stop_server():
    if os.path.exists(PID_FILE):
        with open(PID_FILE, "r") as f:
            pid = int(f.read().strip())
        print(f"Stopping server with PID: {pid}")
        os.kill(pid, signal.SIGTERM)
        os.remove(PID_FILE)
        print("Server stopped.")
    else:
        print("No running server found.")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python ws_server.py run <port> | rok")
        sys.exit(1)

    if sys.argv[1] == "run" and len(sys.argv) == 3:
        port = int(sys.argv[2])
        try:
            asyncio.run(main(port))
        except KeyboardInterrupt:
            shutdown()
    elif sys.argv[1] == "rok":
        stop_server()
    else:
        print("Usage: python ws_server.py run <port> | rok")
