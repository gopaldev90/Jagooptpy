import websocket
import threading
import json
import requests

#admin.py
entries=[]
resetlist=True
def on_message(ws, payload):
    global resetlist,entries
    payload=json.loads(payload)
    message=payload["msg"]
    print("*"*12, payload["user"], "*"*12)
    if "[" in message:
        message=json.loads(message)
        entries=message
        for tatv in message:
            print(tatv)
        #print(entries)
    else:
        if resetlist:
            entries=[]
        print(message)
    print("="*27)
    # To keep console neat

def getdata(kahan):
    url = f"https://jagooptpy-default-rtdb.firebaseio.com/{kahan}.json"
    resp=requests.get(url)
    if resp.status_code==200:
        return resp.json()
    else:
        return "error"

def send_message(chij,ws):
    chij["target"]=None
    chij["target"]="sab"
    ws.send(json.dumps(chij))

def on_open(ws):
    print("Connected to server!")
    def run():
        global entries,resetlist
        while True:
            msg = input("You: ").strip()
            if not msg:
                continue
            if "," in msg:
                args=msg.split(",")
                msg=args[0]
                #print("msg:",msg)
                args.pop(0)
                if args[0]=='*':
                    resetlist=False
                    if len(entries)>0:
                        for entry in entries:
                           payload={"user":"Boss","msg":msg,"args":[entry]}
                           send_message(payload,ws) 
                    else:
                        print("pehle ls cmd do")
                    resetlist=True
                    continue
            else:
                args=[]
            payload={"user":"Boss","msg":msg,"args":args}
            send_message(payload,ws)
    threading.Thread(target=run).start()

serverurl = getdata("websoket_url")
print("Admin app connecting to ",serverurl)
ws = websocket.WebSocketApp(
    serverurl,  # Replace 
    on_message=on_message,
    on_open=on_open
)
ws.run_forever()

