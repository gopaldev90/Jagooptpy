#!/bin/bash
set -euo pipefail

DJANGO_CMD="python3 manage.py runserver 0.0.0.0:8000"
LOCAL_URL="http://127.0.0.1:8000"
TUNNEL_LOG="tunnel.log"
UPDATE_PY="./updateurl.py"
WSPYFILE="./ws_server.py"
cleanup() {
    echo "Shutting down..."
    if [ -n "${DJANGO_CLOUDFLARED_PID:-}" ]; then
        echo "Stopping django url cloudflared (PID $DJANGO_CLOUDFLARED_PID)"
        kill "$DJANGO_CLOUDFLARED_PID" 2>/dev/null || true
    fi
    if [ -n "${DJANGO_PID:-}" ]; then
        echo "Stopping Django dev server (PID $DJANGO_PID)"
        kill "$DJANGO_PID" 2>/dev/null || true
    fi
    python3 "$UPDATE_PY" "error" "upload_url" || echo "⚠️ Failed to update Firebase"
    exit $?
}
trap cleanup SIGINT SIGTERM

# --- ✅ Check if Django server is already running ---
if lsof -i:8000 >/dev/null 2>&1; then
    echo "✅ Django dev server already running on port 8000. Skipping start."
elif [ 7 -le 8 ]; then
    echo "Starting Django dev server..."
    $DJANGO_CMD > django.log 2>&1 &
    DJANGO_PID=$!
    echo "Django PID: $DJANGO_PID"
fi

# --- Wait until server is ready ---
echo "Waiting for local server at $LOCAL_URL ..."
RETRIES=30
while [ $RETRIES -gt 0 ]; do
    if curl -s --head "$LOCAL_URL" >/dev/null 2>&1; then
        echo "✅ Local server is up."
        break
    fi
    sleep 1
    RETRIES=$((RETRIES-1))
done

if [ $RETRIES -le 0 ]; then
    echo "❌ Local server did not start. Exiting."
    cleanup
fi

# --- Start Cloudflared ---
echo "Starting Cloudflared tunnel..."
cloudflared tunnel --url http://localhost:8000 --loglevel info > "$TUNNEL_LOG" 2>&1 &
DJANGO_CLOUDFLARED_PID=$!
echo "Cloudflared PID: $DJANGO_CLOUDFLARED_PID"

# --- Wait for URL to appear ---
echo "Waiting for public URL..."
MAX_WAIT=60
SLEPT=0
TUNNEL_URL=""
while [ $SLEPT -lt $MAX_WAIT ]; do
    TUNNEL_URL=$(grep -o 'https://.*trycloudflare.com' "$TUNNEL_LOG" | tail -n1 || true)
    if [ -n "$TUNNEL_URL" ]; then
        echo "🌐 upload_url ready: $TUNNEL_URL"
        break
    fi
    sleep 1
    SLEPT=$((SLEPT+1))
done

if [ -z "$TUNNEL_URL" ]; then
    echo "❌ Tunnel URL not found. Exiting."
    cleanup
fi

# --- Update Firebase ---
if [ -f "$UPDATE_PY" ]; then
    echo "📡 Updating Firebase..."
    python3 "$UPDATE_PY" "$TUNNEL_URL" "upload_url" || echo "⚠️ Failed to update Firebase"
    
    PORT=8002
    if lsof -i:8002 >/dev/null 2>&1; then
        echo "✅ WebSocket server already running on port $PORT. Skipping start."
    else
        echo "Starting WebSocket server on port $PORT..."
        python3 "$WSPYFILE" "run" "$PORT"
        #> ws.log 2>&1 &
        echo "WebSocket PID: $WSPID"
    fi
else
    echo "⚠️ Skipping Firebase update — no updateurl.py found."
fi

echo "✅ Tunnel running successfully!"
echo "Press Ctrl+C to stop."
while true; do sleep 60; done
