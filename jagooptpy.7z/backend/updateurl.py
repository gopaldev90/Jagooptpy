import sys
import json
import requests
import google.auth.transport.requests
from google.oauth2 import service_account

def updatevalue(key, url):
    SERVICE_ACCOUNT_FILE = "ServiceAccountKey.json"
    FIREBASE_URL = f"https://jagooptpy-default-rtdb.firebaseio.com/{key}.json"
    # ---
    # Load credentials and generate access token
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE,
        scopes=["https://www.googleapis.com/auth/firebase.database",
                "https://www.googleapis.com/auth/userinfo.email"]
    )
    auth_req = google.auth.transport.requests.Request()
    credentials.refresh(auth_req)
    # Send PUT request to Firebase
    params = {"access_token": credentials.token}
    response = requests.put(FIREBASE_URL, params=params, json=url)
    parn=response.status_code == 200
    if parn:
        print("Updated")
        print({key:url})
    else:
        print(f"Failed ({response.status_code}): {response.text}")
    
    return int(not parn)

if(__name__=="__main__"):
    if len(sys.argv) < 3:
        print("Usage: python updateurl.py <url> <key>")
        sys.exit(1)
    url = sys.argv[1]
    key = sys.argv[2]
    sys.exit(updatevalue(key,url))
    
